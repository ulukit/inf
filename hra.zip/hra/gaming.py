import random as rand
import copy

karty = [2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10]

deck = [2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10,2,3,4,5,6,7,8,9,10,10,10,10]

player=[]
dealer=[]

e = 1
p = 1

while e == 1:
    p1 = 1
    p2 = 1
    rand.shuffle(deck)
    for i in range(2):
        player.append(deck[0])
        del deck[0]
    for i in range(2):
        dealer.append(deck[0])
        del deck[0]
    print("your hand:",player)
    print("dealer's hand:",dealer)
#loop to see if game should continue
    while p1+p2 != 0:
#to see if player stands
        if p1==1:
            ask = input("press s to stand or h to hit: ")
            if ask == "s":
                p1 = 0
            if ask == "h":
                player.append(deck[0])
                del deck[0]
#to see if dealer stands
        if sum(dealer) < 17:
            dealer.append(deck[0])
            del deck[0]
        elif sum(dealer) > 16:
            p2 = 0
        print(player)
        print(dealer)

    e = 0
#deck = copy.deepcopy(karty)
